"""
大数据标签系统核心模块
"""

__version__ = "1.0.0"
__author__ = "Tag System Team"
"""
生命周期类标签任务
"""

from .new_user_task import NewUserTask
from .vip_user_task import VIPUserTask

__all__ = ['NewUserTask', 'VIPUserTask']
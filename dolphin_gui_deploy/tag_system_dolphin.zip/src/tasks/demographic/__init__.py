"""
人口特征类标签任务
"""

from .young_user_task import YoungUserTask

__all__ = ['YoungUserTask']
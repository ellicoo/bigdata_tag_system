"""
风险等级类标签任务
"""

from .low_risk_task import LowRiskUserTask

__all__ = ['LowRiskUserTask']
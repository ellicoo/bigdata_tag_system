#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MySQL数据源管理类
负责标签规则、现有标签数据的读取和标签结果的写入
"""
import pymysql
from typing import List, Dict, Optional
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.functions import *
from pyspark.sql.types import *
from ..utils.SparkUdfs import json_to_array


class MysqlMeta:
    """MySQL数据源管理器
    
    职责：
    1. 加载标签规则数据
    2. 加载现有用户标签数据
    3. 写入标签计算结果
    4. 管理MySQL连接和JDBC配置
    """
    
    def __init__(self, spark: SparkSession, mysqlConfig: Dict[str, str]):
        """初始化MySQL数据源管理器
        
        Args:
            spark: Spark会话
            mysqlConfig: MySQL连接配置
        """
        self.spark = spark
        self.mysqlConfig = mysqlConfig
        self.jdbcUrl = self._buildJdbcUrl()
        
        print("🗄️  MysqlMeta初始化完成")
    
    def _buildJdbcUrl(self) -> str:
        """构建JDBC连接URL"""
        host = self.mysqlConfig['host']
        port = self.mysqlConfig['port']
        database = self.mysqlConfig['database']
        
        # 使用connectionCollation参数支持utf8mb4编码
        return f"jdbc:mysql://{host}:{port}/{database}?useSSL=false&useUnicode=true&connectionCollation=utf8mb4_unicode_ci&serverTimezone=UTC"
    
    def loadTagRules(self, tagIds: Optional[List[int]] = None) -> DataFrame:
        """加载标签规则DataFrame
        
        Args:
            tagIds: 指定加载的标签ID列表，None表示加载所有活跃标签
            
        Returns:
            DataFrame: 标签规则DataFrame，包含字段：tag_id, rule_conditions, tag_name
        """
        print(f"📋 加载标签规则，指定标签: {tagIds}")
        
        # 构建查询SQL
        query = """
        (SELECT tr.tag_id, tr.rule_conditions, td.tag_name, td.description
         FROM tag_rules tr
         LEFT JOIN tag_definition td ON tr.tag_id = td.tag_id
         WHERE tr.is_active = 1
        """
        
        if tagIds:
            tagIdsStr = ','.join(map(str, tagIds))
            query += f" AND tr.tag_id IN ({tagIdsStr})"
        
        query += " ORDER BY tr.tag_id) as tag_rules"
        
        try:
            rulesDF = self.spark.read \
                .format("jdbc") \
                .option("url", self.jdbcUrl) \
                .option("dbtable", query) \
                .option("user", self.mysqlConfig['user']) \
                .option("password", self.mysqlConfig['password']) \
                .option("driver", "com.mysql.cj.jdbc.Driver") \
                .load()
            
            print(f"✅ 标签规则加载完成: {rulesDF.count()} 个标签")
            return rulesDF
            
        except Exception as e:
            print(f"❌ 加载标签规则失败: {e}")
            return self._createEmptyRulesDataFrame()
    
    def loadExistingTags(self) -> DataFrame:
        """加载现有用户标签DataFrame
        
        Returns:
            DataFrame: 现有标签DataFrame，包含字段：user_id, existing_tag_ids(Array)
        """
        print("📖 加载现有用户标签数据...")
        
        query = "(SELECT user_id, tag_ids FROM user_tags WHERE tag_ids IS NOT NULL) as existing_tags"
        
        try:
            existingDF = self.spark.read \
                .format("jdbc") \
                .option("url", self.jdbcUrl) \
                .option("dbtable", query) \
                .option("user", self.mysqlConfig['user']) \
                .option("password", self.mysqlConfig['password']) \
                .option("driver", "com.mysql.cj.jdbc.Driver") \
                .load()
            
            # 使用SparkUdfs模块转换JSON为Array
            existingDF = existingDF.withColumn(
                "existing_tag_ids",
                json_to_array(col("tag_ids"))
            ).select("user_id", "existing_tag_ids")
            
            print(f"✅ 现有标签数据加载完成: {existingDF.count()} 个用户")
            return existingDF
            
        except Exception as e:
            print(f"❌ 加载现有标签数据失败: {e}")
            return self._createEmptyExistingTagsDataFrame()
    
    def writeTagResults(self, resultsDF: DataFrame) -> bool:
        """写入标签计算结果到MySQL - 分布式并发写入优化版本
        
        Args:
            resultsDF: 结果DataFrame，包含字段：user_id, final_tag_ids_json
            
        Returns:
            bool: 写入是否成功
        """
        print("💾 开始分布式写入标签结果到MySQL...")
        
        # 初始化广播变量
        mysqlConfigBroadcast = None
        
        try:
            # 先检查是否有数据需要写入
            totalCount = resultsDF.count()
            if totalCount == 0:
                print("⚠️  没有结果需要写入")
                return True
            
            print(f"📤 准备分布式写入 {totalCount} 条标签记录...")
            
            # 🚀 关键优化：使用foreachPartition实现分布式并发写入
            # 将MySQL配置广播到所有Executor节点
            mysqlConfigBroadcast = resultsDF.sparkSession.sparkContext.broadcast(self.mysqlConfig)
            
            def writePartitionToMySQL(partition_data):
                """每个分区独立写入MySQL的函数"""
                import pymysql
                import time
                
                # 获取广播的MySQL配置
                mysql_config = mysqlConfigBroadcast.value
                
                # 将迭代器转换为列表（避免多次迭代）
                rows = list(partition_data)
                
                if not rows:
                    return  # 空分区直接返回
                
                partition_count = len(rows)
                start_time = time.time()
                print(f"🔄 分区开始写入 {partition_count} 条记录...")
                
                try:
                    # 每个分区建立独立的MySQL连接
                    connection = pymysql.connect(**mysql_config)
                    
                    try:
                        with connection.cursor() as cursor:
                            # UPSERT SQL，保持原有的ON DUPLICATE KEY UPDATE逻辑
                            upsertSql = """
                            INSERT INTO user_tags (user_id, tag_ids) 
                            VALUES (%s, %s)
                            ON DUPLICATE KEY UPDATE
                                updated_time = CASE 
                                    WHEN JSON_EXTRACT(tag_ids, '$') <> JSON_EXTRACT(VALUES(tag_ids), '$')
                                    THEN CURRENT_TIMESTAMP 
                                    ELSE updated_time 
                                END,
                                tag_ids = VALUES(tag_ids)
                            """
                            
                            # 准备批量数据
                            batchData = [(row['user_id'], row['final_tag_ids_json']) for row in rows]
                            
                            # 🎯 动态批次大小：根据分区数据量智能调整
                            """
                            | 批次大小  | 优点                 | 缺点               | 适用场景         |
                            |---------|----------------------|-------------------|-----------------|
                            | 100     | 事务小，快速提交，低风险 | 网络往返多，总体较慢 | 高并发，小数据量   |
                            | 500     | 平衡性能和风险         | 中等风险            | 推荐：通用场景    |
                            | 1000    | 高吞吐，网络往返少      | 事务大，锁定时间长    | 低并发，大数据量  |
                            | 2000+   | 最高吞吐              | 高风险，可能超时      | 专用环境，高性能硬件|
                          """
                            if partition_count <= 100:
                                batchSize = partition_count  # 小数据量，一次性处理
                            elif partition_count <= 1000:
                                batchSize = 250  # 中等数据量，保守批次
                            elif partition_count <= 5000:
                                batchSize = 500  # 大数据量，平衡批次
                            else:
                                batchSize = 1000  # 超大数据量，大批次提升吞吐
                            
                            print(f"   📦 分区数据 {partition_count} 条，批次大小 {batchSize}")
                            
                            # 分批执行并显示进度
                            total_batches = (len(batchData) + batchSize - 1) // batchSize
                            for i in range(0, len(batchData), batchSize):
                                batch = batchData[i:i + batchSize]
                                batch_num = i // batchSize + 1
                                
                                cursor.executemany(upsertSql, batch)
                                print(f"   ⚡ 分区批次 {batch_num}/{total_batches} 完成 ({len(batch)} 条)")
                                
                            # 提交事务
                            connection.commit()
                            
                            elapsed_time = time.time() - start_time
                            print(f"   ✅ 分区写入完成: {partition_count} 条记录，耗时 {elapsed_time:.2f}s")
                            
                    finally:
                        connection.close()
                        
                except Exception as e:
                    # 分区级别的错误处理
                    elapsed_time = time.time() - start_time
                    print(f"   ❌ 分区写入失败: {e}，耗时 {elapsed_time:.2f}s")
                    raise e
            
            # 🚀 执行分布式写入：每个分区并发执行写入操作
            resultsDF.select("user_id", "final_tag_ids_json").foreachPartition(writePartitionToMySQL)
            
            print(f"✅ 分布式标签结果写入完成: {totalCount} 条记录")
            return True
            
        except Exception as e:
            print(f"❌ 分布式写入标签结果失败: {e}")
            import traceback
            traceback.print_exc()
            return False
        finally:
            # 清理广播变量
            try:
                mysqlConfigBroadcast.unpersist()
            except:
                pass
    
    def testConnection(self) -> bool:
        """测试MySQL连接
        
        Returns:
            bool: 连接是否成功
        """
        try:
            connection = pymysql.connect(**self.mysqlConfig)
            connection.close()
            print("✅ MySQL连接测试成功")
            return True
        except Exception as e:
            print(f"❌ MySQL连接测试失败: {e}")
            return False
    
    def _createEmptyRulesDataFrame(self) -> DataFrame:
        """创建空的标签规则DataFrame"""
        schema = StructType([
            StructField("tag_id", IntegerType(), False),
            StructField("rule_conditions", StringType(), True),
            StructField("tag_name", StringType(), True),
            StructField("description", StringType(), True)
        ])
        
        return self.spark.createDataFrame([], schema)
    
    def _createEmptyExistingTagsDataFrame(self) -> DataFrame:
        """创建空的现有标签DataFrame"""
        schema = StructType([
            StructField("user_id", StringType(), False),
            StructField("existing_tag_ids", ArrayType(IntegerType()), True)
        ])
        
        return self.spark.createDataFrame([], schema)
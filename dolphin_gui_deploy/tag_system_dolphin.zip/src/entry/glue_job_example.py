#!/usr/bin/env python3
"""
AWS Glue作业示例 - 使用新的程序入口
演示如何在Glue中使用src/entry模块
"""

import sys
import os
import logging
from awsglue.utils import getResolvedOptions
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.context import SparkContext

# 添加项目路径
sys.path.append('/opt/ml/code')  # Glue作业代码路径

# 导入新的入口模块
from src.entry.spark_task_executor import SparkTaskExecutor, JavaAPIInterface
from src.entry.glue_entry import execute_glue_job


def main():
    """Glue作业主函数 - 使用新的入口设计"""
    
    # 解析Glue参数
    try:
        args = getResolvedOptions(sys.argv, [
            'JOB_NAME',
            'mode',
            'tag_ids',
            'user_ids',
            'log_level',
            'environment'
        ])
    except Exception:
        # 使用默认参数
        args = {
            'JOB_NAME': 'tag-compute-example',
            'mode': 'health',
            'log_level': 'INFO',
            'environment': 'glue-dev'
        }
    
    # 设置日志
    logging.basicConfig(
        level=getattr(logging, args.get('log_level', 'INFO')),
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    logger = logging.getLogger(__name__)
    
    logger.info(f"🚀 启动Glue作业示例: {args.get('JOB_NAME')}")
    
    # 初始化Glue上下文
    sc = SparkContext()
    glueContext = GlueContext(sc)
    spark = glueContext.spark_session
    job = Job(glueContext)
    job.init(args.get('JOB_NAME'), args)
    
    try:
        mode = args.get('mode', 'health')
        environment = args.get('environment', 'glue-dev')
        
        logger.info(f"🎯 执行模式: {mode}, 环境: {environment}")
        
        # 方式1: 使用SparkTaskExecutor（推荐）
        executor = SparkTaskExecutor(environment, args.get('log_level', 'INFO'))
        
        # 构建任务配置
        task_config = {'task_type': mode}
        
        if 'tag_ids' in args and args['tag_ids']:
            tag_ids = [int(x.strip()) for x in args['tag_ids'].split(',')]
            task_config['tag_ids'] = tag_ids
            
        if 'user_ids' in args and args['user_ids']:
            user_ids = [x.strip() for x in args['user_ids'].split(',')]
            task_config['user_ids'] = user_ids
        
        # 执行任务
        result = executor.execute_task(task_config)
        
        logger.info(f"📋 任务执行结果: {result}")
        
        exit_code = 0 if result['success'] else 1
        
        # 方式2: 使用传统接口（兼容性）
        # success = execute_glue_job(mode, environment, **task_config)
        # exit_code = 0 if success else 1
        
    except Exception as e:
        logger.error(f"❌ Glue作业执行异常: {e}")
        logger.error("📋 异常详情:", exc_info=True)
        exit_code = 1
    
    finally:
        job.commit()
        logger.info("👋 Glue作业结束")
    
    return exit_code


def java_api_example():
    """Java API调用示例"""
    
    print("🧪 Java API调用示例...")
    
    # 示例1: 健康检查
    result = JavaAPIInterface.execute_health_check('glue-dev')
    print(f"健康检查结果: {result}")
    
    # 示例2: 执行指定标签
    result = JavaAPIInterface.execute_specific_tags('1,2,3', 'glue-dev')
    print(f"指定标签结果: {result}")
    
    # 示例3: 批量执行
    batch_config = '''[
        {"task_type": "health"},
        {"task_type": "task-tags", "tag_ids": [1, 2, 3]},
        {"task_type": "list-tasks"}
    ]'''
    
    result = JavaAPIInterface.execute_batch_from_json(batch_config, 'glue-dev')
    print(f"批量执行结果: {result}")


if __name__ == "__main__":
    # 如果是直接运行（测试模式），执行Java API示例
    if len(sys.argv) == 1:
        java_api_example()
    else:
        # 如果有参数，按Glue作业方式运行
        exit_code = main()
        sys.exit(exit_code)
#!/usr/bin/env python3
"""
AWS Glue专用入口模块
提供统一的Glue任务执行接口，支持Java API触发
"""

import sys
import os
import logging
from typing import List, Optional, Dict, Any

# 添加项目路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.entry.tag_system_api import TagSystemAPI


def setup_glue_logging(log_level: str = "INFO") -> logging.Logger:
    """设置Glue环境日志"""
    logging.basicConfig(
        level=getattr(logging, log_level.upper()),
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        force=True
    )
    return logging.getLogger("GlueEntry")


def execute_glue_job(mode: str, environment: str = 'glue-dev', **kwargs) -> bool:
    """
    Glue作业统一执行入口
    支持Java API触发调用
    
    Args:
        mode: 执行模式 ('health', 'task-all', 'task-tags', 'task-users', 'list-tasks')
        environment: 环境 ('local', 'glue-dev', 'glue-prod')
        **kwargs: 其他参数
            - tag_ids: List[int] 标签ID列表
            - user_ids: List[str] 用户ID列表
            - log_level: str 日志级别
            
    Returns:
        bool: 执行是否成功
    """
    logger = setup_glue_logging(kwargs.get('log_level', 'INFO'))
    logger.info(f"🚀 Glue作业执行 - 模式: {mode}, 环境: {environment}")
    
    try:
        # 标准化模式名
        mode = mode.lower().strip()
        
        # 获取参数
        tag_ids = kwargs.get('tag_ids', [])
        user_ids = kwargs.get('user_ids', [])
        log_level = kwargs.get('log_level', 'INFO')
        
        # 参数验证和转换
        if isinstance(tag_ids, str):
            tag_ids = [int(x.strip()) for x in tag_ids.split(',') if x.strip()]
        if isinstance(user_ids, str):
            user_ids = [x.strip() for x in user_ids.split(',') if x.strip()]
        
        logger.info(f"📋 执行参数 - 标签数: {len(tag_ids)}, 用户数: {len(user_ids)}")
        
        # 根据模式执行对应任务
        with TagSystemAPI(environment, log_level=log_level) as api:
            
            if mode == 'health':
                logger.info("🏥 执行健康检查")
                return api.health_check()
                
            elif mode == 'task-all':
                logger.info("🎯 执行所有任务")
                if api.health_check():
                    return api.run_task_all_users_all_tags()
                return False
                
            elif mode == 'task-tags':
                if not tag_ids:
                    logger.error("❌ task-tags模式需要提供tag_ids参数")
                    return False
                logger.info(f"🎯 执行指定标签任务: {tag_ids}")
                if api.health_check():
                    return api.run_task_specific_tags(tag_ids)
                return False
                
            elif mode == 'task-users':
                if not user_ids or not tag_ids:
                    logger.error("❌ task-users模式需要提供user_ids和tag_ids参数")
                    return False
                logger.info(f"🎯 执行指定用户指定标签任务")
                if api.health_check():
                    return api.run_task_specific_users_specific_tags(user_ids, tag_ids)
                return False
                
            elif mode == 'list-tasks':
                logger.info("📋 列出可用任务")
                tasks = api.list_available_tasks()
                for task in tasks:
                    logger.info(f"  📋 任务: {task}")
                return len(tasks) > 0
                
            else:
                logger.error(f"❌ 不支持的执行模式: {mode}")
                return False
                
    except Exception as e:
        logger.error(f"❌ Glue作业执行失败: {e}")
        logger.error("📋 异常详情:", exc_info=True)
        return False


# Java API触发专用函数
def glue_health_check(environment: str = 'glue-dev') -> bool:
    """Java API专用 - 健康检查"""
    return execute_glue_job('health', environment)


def glue_run_all_tasks(environment: str = 'glue-dev') -> bool:
    """Java API专用 - 执行所有任务"""
    return execute_glue_job('task-all', environment)


def glue_run_specific_tags(tag_ids: List[int], environment: str = 'glue-dev') -> bool:
    """Java API专用 - 执行指定标签"""
    return execute_glue_job('task-tags', environment, tag_ids=tag_ids)


def glue_run_specific_users_tags(user_ids: List[str], tag_ids: List[int], environment: str = 'glue-dev') -> bool:
    """Java API专用 - 执行指定用户指定标签"""
    return execute_glue_job('task-users', environment, user_ids=user_ids, tag_ids=tag_ids)


def glue_list_available_tasks(environment: str = 'glue-dev') -> bool:
    """Java API专用 - 列出可用任务"""
    return execute_glue_job('list-tasks', environment)


# 批量执行接口（用于复杂场景）
def glue_batch_execute(job_requests: List[Dict[str, Any]], environment: str = 'glue-dev') -> Dict[str, bool]:
    """
    批量执行任务（Java API高级接口）
    
    Args:
        job_requests: 任务请求列表，每个请求包含 mode, tag_ids, user_ids 等参数
        environment: 环境
        
    Returns:
        Dict[str, bool]: 每个任务的执行结果
        
    Example:
        requests = [
            {'mode': 'task-tags', 'tag_ids': [1, 2, 3]},
            {'mode': 'task-tags', 'tag_ids': [4, 5, 6]},
            {'mode': 'task-users', 'user_ids': ['user1'], 'tag_ids': [1, 2]}
        ]
        results = glue_batch_execute(requests, 'glue-dev')
    """
    logger = setup_glue_logging('INFO')
    logger.info(f"🎯 批量执行任务 - 任务数: {len(job_requests)}")
    
    results = {}
    
    for i, request in enumerate(job_requests):
        job_id = f"job_{i+1}"
        mode = request.get('mode', 'health')
        
        try:
            logger.info(f"📋 执行任务 {job_id}: {mode}")
            success = execute_glue_job(mode, environment, **request)
            results[job_id] = success
            
            status = "成功" if success else "失败"
            logger.info(f"✅ 任务 {job_id} {status}")
            
        except Exception as e:
            logger.error(f"❌ 任务 {job_id} 执行异常: {e}")
            results[job_id] = False
    
    success_count = sum(results.values())
    logger.info(f"🎉 批量执行完成 - 成功: {success_count}/{len(job_requests)}")
    
    return results


if __name__ == "__main__":
    # 测试用例
    print("🧪 测试Glue入口模块...")
    
    # 测试健康检查
    if execute_glue_job('health', 'local'):
        print("✅ 健康检查通过")
        
        # 测试指定标签
        success = execute_glue_job('task-tags', 'local', tag_ids=[1, 3, 5])
        print(f"🎯 指定标签测试: {'成功' if success else '失败'}")
        
        # 测试批量执行
        requests = [
            {'mode': 'list-tasks'},
            {'mode': 'task-tags', 'tag_ids': [1, 2]}
        ]
        results = glue_batch_execute(requests, 'local')
        print(f"📋 批量执行结果: {results}")
        
    else:
        print("❌ 健康检查失败")